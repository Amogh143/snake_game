/**
 * 
 */
/**
 * @author Raviteja T S
 *
 */
module Snake {
	requires java.desktop;
}